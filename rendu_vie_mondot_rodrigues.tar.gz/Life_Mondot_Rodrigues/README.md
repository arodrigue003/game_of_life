# Versions :
 * 0 : Séquentielle
 * 1 : Séquentielle tuilée
 * 2 : Séquentielle optimisé
 * 3 : OpenMP for
 * 4 : OpenMP for tuilé
 * 5 : OpenMp for optimisé
 * 6 : OpenMP task tuilé
 * 7 : OpenMP task optimisé
 * 8 : OpenCL (kernels naïfs et tuilés)
 * 9 : OpenCL optimisé (kernel optimisé)
 * 10 : Hybride (kernels naïfs et tuilés)

# Architecture :
 * experiences : scripts de lancement des expériences et résultat de celles-ci
 * include : fichiers headers
 * kernel : kernels OpenCL
 * rle : fichiers exemples Golly
 * src : sources c
